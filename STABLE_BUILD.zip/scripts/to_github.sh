#!/bin/bash

echo
echo "Hello User!"

echo "I am pushing your changes to Github Now..."
echo
echo

if [ -z "$(git status --porcelain)" ]; then 
  echo "Working directory clean."
else 
  git add --all

	git commit -m "changes"

	git push
fi

echo
echo
echo "Returning command prompt to you..."